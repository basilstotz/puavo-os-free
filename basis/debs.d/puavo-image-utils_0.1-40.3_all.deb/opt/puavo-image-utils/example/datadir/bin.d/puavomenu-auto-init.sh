#!/bin/sh

echo "saving state of applications"
ls /usr/share/applications/ > /tmp/applications.list


exit 0
